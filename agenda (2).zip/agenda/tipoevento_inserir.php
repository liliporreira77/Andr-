<?php verifica_session();
?>
 <div class="container content__boxed" style="text-align: center;">
     <div id="divCenter">
         <div class="form-block">
             <h1>Novo tipo de evento <br> </h1>
             <h1> </h1>
             <form method="post" action="" id="novoregisto">
                 <div id="msg_num_mec"></div>
                 <div id="formfields">
                     <label for="descricao" class="form-itens">Nome do tipo de evento: </label>
                     <div class="form-itens">
                         <input type="text" name="nome" id="nome" placeholder="Insira o nome do tipo de evento"
                             autofocus><br>
                     </div>
                   
                     <label for="descricao" class="form-itens">Selecione a cor do evento: </label>
                     <div class="form-itens">
                         <input type="color" name="color" id="color">
                     </div>

                     <br><br>
                     <div class="labelbotton">
                         <input class="button-default form-submit" id="submit_new_user" type="button"
                             value="Inserir evento">
                     </div>
                 </div>
             </form>
         </div>
     </div>
 </div>
 <script type="text/javascript">
$(document).ready(function() {
    //validação
    $('#submit_new_user').click(function() {
        var oNome = $('#nome').val();
        var acor = document.getElementById("color").value;
        $.ajax({
            url: "tipoevento_inserir_actions.php",
            type: "POST",
            data: {
                nome: oNome,
                color: acor
            }
        }).done(function(data) {
            if (data == 0) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O tipo de evento foi inserido com sucesso!</div>'
                );
            }
            if (data == 2) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Todos os campos são de preenchimento obrigatório. Por favor, preencha os campos vazios.</div>'
                );
                $('#Terminar Registo').prop('disabled', true);
            }
            if (data == 4) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já existe outro tipo de evento com o mesmo nome!</div>'
                );
            }            
            if (data == 1) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já existe outro tipo de evento com a mesma cor!</div>'
                );
            }

        }).fail(function(jqXHR, textStatus) {
            console.log("Request failed: " + textStatus);
        });
    });
});
 </script>