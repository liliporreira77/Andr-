<?php

// Incluir o arquivo com a conexão com banco de dados
include_once './conexao.php';
// // Receber os dados enviado pelo JavaScript
$color_id = filter_input(INPUT_GET, 'color_id', FILTER_SANITIZE_NUMBER_INT);
if (!empty($color_id)){
// QUERY para recuperar os eventos
$query_events = "SELECT events.id, events.image, events.title, events.start, events.end, events.obs, events.color_id, events.user_id, color.color_id, color.nome_tipo, color.color, login.user_id, login.nome_login FROM login INNER JOIN (color INNER JOIN events ON color.color_id = events.color_id) ON (login.user_id = events.user_id) AND (login.user_id = events.user_id) Where events.color_id=:color_id";

  // Prepara a QUERY
  $result_events = $conn->prepare($query_events);

  // Atribuir o valor do parâmetro
  $result_events->bindParam(':color_id', $color_id, PDO::PARAM_INT);
}else{
       // QUERY para recuperar os eventos
    $query_events = "SELECT events.id, events.image, events.title, events.start, events.end, events.obs, events.color_id, events.user_id, color.color_id, color.nome_tipo, color.color, login.user_id, login.nome_login FROM login INNER JOIN (color INNER JOIN events ON color.color_id = events.color_id) ON (login.user_id = events.user_id) AND (login.user_id = events.user_id)";

// Prepara a QUERY
$result_events = $conn->prepare($query_events);
}



// Executar a QUERY
$result_events->execute();

// Criar o array que recebe os eventos
$eventos = [];

// Percorrer a lista de registros retornado do banco de dados
while($row_events = $result_events->fetch(PDO::FETCH_ASSOC)){

    // Extrair o array
    extract($row_events);

    $eventos[] = [
        'id' => $id,
        'title' => $title,
        'color_id' => $color_id,
        'color' => $color,
        'nome_tipo' => $nome_tipo,
        'start' => $start,
        'end' => $end,
        'obs' => $obs,
        'user_id' => $user_id,
        'nome_login' => $nome_login,
        'image'=> $image,
    ];
}


echo json_encode($eventos);