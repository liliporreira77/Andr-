<?php 
// verifica_nivel();
require('core/conexao.php');
?>
<!-- MDBootstrap Datatables  -->
<div class='container-fluid'>
<div class="rowT" style="margin-left: 3em !important;font-size: 0.9em!important;">
        <div class='col-12' style='padding-top:25px;'>
            <table id='example' class='table table-striped table-bordered'>
                <thead>
                    <!--O numero de colunas-->
                    <tr>
                        <th></th>

                        <th class="tableth" style="text-align: center;">Nome</th>
                        <th class="tableth" style="text-align: center;">E-mail</th>
  
                        <th class="tableth">Ações</th>
                    </tr>
                </thead>
                <tbody> <?php
                        echo '<tr>';
                            $result = "SELECT user_id, nome_login, email, hash_session FROM login order by  login.nome_login asc";
                            $resultado = mysqli_query($con, $result);
                            while ($row = mysqli_fetch_assoc($resultado)) {
                                if ($row['hash_session'] != 0)
                                    echo '<td align=left style="width: 2px;font-size: 11px; color: dimgray;"> <i class="fas fa-key"></i> </td> ';
                                else echo '<td align=left style="width: 2px;font-size: 11px; color: dimgray;"> </td> ';
                                //else echo '<td align=left style="width: 2px;font-size: 11px; color: dimgray;"> </td> ';
                                echo '<td style="width:160px" align=left><b>' . $row['nome_login'] . ' </b> | ' . $row['user_id'] . '</td> ';
                                echo '<td align=center style="width:240px">' . $row['email'] . '</td> ';
                        ?>
                        <td style="padding: 4px; width:80px; text-align: center;">
                            <button type="button"
                                onclick="acaoDoAdministrador('<?php echo $row['user_id']; ?>','password');"
                                class="btn btn-primary btn-sm btn-admin-actions"
                                title="Reenviar email de autenticação"><i class="fas fa-envelope"></i></button>
                            <button type="button"
                                onclick="acaoDoAdministrador('<?php echo $row['user_id']; ?>','delete');"
                                class="btn btn-danger btn-sm btn-admin-actions" title="Apagar"><span
                                    class="fas fa-times fa-sm"></span> </button>
                            <button type="button"
                                onclick="acaoDoAdministrador('<?php echo $row['user_id']; ?>','edit');"
                                class="btn btn-success btn-sm btn-admin-actions" title="Editar"><span
                                    class="fas fa-user-edit fa-sm"></span> </button>
                        </td>
                            </td> 
                        <?php
                        echo '</tr>'; } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<script src="assets/js/datatables.min.js"></script>

<script type="text/javascript">
let table = new DataTable('#example', {
    "ordering": true,
    language: {
        sSearch: '',
        searchPlaceholder: 'Procurar',
        lengthMenu: 'Apresentar _MENU_ linhas por página',
        zeroRecords: 'Não há registos',
        info: 'A mostrar a página _PAGE_ de _PAGES_',
        infoEmpty: 'Não há registos',
        infoFiltered: '(Foram encontrados _MAX_ registos)',
    }
});

function acaoDoAdministrador(id, acao) {
    if (acao == 'password') {
        if (confirm('Pertende enviar nova password para este utilizador?')) {

            // Save it!
            var action_type = 1;
        }
    } else if (acao == 'delete') {
        if (confirm("Pertende apagar este utilizador dos contactos?")) {
            var action_type = 2; // se for do tipo "deletar usuário do sistema"
            $('#msg_num_mec').html(
                '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">A lista de utilizadores foi atualizada com sucesso. </div>'

            );
        }
        // alert('Pertende apagar  dos contactos?');
        // var action_type = 2; // se for do tipo "deletar usuário do sistema"

    } else if (acao == 'edit') {
        var action_type = 3; // se for do tipo "editar dados do usuário"
    }

    //Faz a requisição para o script em "registo_todos_actions.php"
    $.ajax({
        url: "login_todos_actions.php",
        type: "POST",
        data: {
            id: id,
            acttp: action_type
        },
        dataType: "json",
        success: function(data) {
            //alert(data);
            //console.log (data);
            if (data.retorno == 1) {
                window.location.href = "?pg=4&userid=" + data.userid;
            } else if (data.retorno == 0) {
                setTimeout(function() {
                    window.location.reload();
                }, 2500);
            }

        }
    });
}
</script>
