<?php
ob_start();
// ini_set('session.cookie_lifetime', 30*60);
//session_name(md5('seg'.$_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']));
//$session_name = session_name();

if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

function verifica_session()
{

	if (!isset($_SESSION)) {
		session_start();
	}
	if (isset($_SESSION['registro'])) {
		$segundos = time() - $_SESSION['registro'];
	} else
		exit('<div class="container content__boxed">Login inválido!</div>');

	if ($segundos > $_SESSION['limite']) {
		unset($_SESSION['registro']);
		unset($_SESSION['limite']);
		unset($_SESSION['user_id']);
		unset($_SESSION['num']);
		unset($_SESSION['nome_login']);
		unset($_SESSION['hash_session']);
		session_destroy();
		header("Location:index.php");
	} else {
		$_SESSION['registro'] = time();
	}
	if (!isset($_SESSION['hash_session'])) {
		exit('<div class="container content__boxed">Login efetuado com sucesso!</div>');
	}
}

function session_item()
{
	$hash = md5(date('d/m/Y'));

	if (!isset($_SESSION['hash_session'])) {
		return 0;
	} else {
		return 1;
	}
}

function verifica_nivel()
{
	if ($_SESSION['nivel_id'] != 1) {
		exit('Esta página só está acessível aos administradores!');
	}
}


#----------------------------------------------#
# CONFIGURAÇÃO
#----------------------------------------------#

$hostname_conexao = "localhost";
$username_conexao = "root";
$password_conexao = "";
$database_conexao = "agenda";

#----------------------------------------------#
# EXECUTA CONEXÃO COM O BD
#----------------------------------------------#

$mysqli = new mysqli($hostname_conexao, $username_conexao, $password_conexao, $database_conexao);

if ($mysqli->connect_errno) {
	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

if (!$mysqli->set_charset("utf8")) {
	printf("Error loading character set utf8: %s\n", $mysqli->error);
	exit();
}

#----------------------------------------------#
# CONFIGURAÇÃO GLOBAL
#----------------------------------------------#

date_default_timezone_set('Europe/Lisbon');
setlocale(LC_TIME, 'pt_PT', 'pt_PT.utf-8', 'pt_PT.utf-8', 'portuguese');

#----------------------------------------------#
# CONFIGURAÇÕES
#----------------------------------------------#

//Pasta do seu projeto em Localhost
//Modificar caso tenha uma subpasta em server ou deixar em branco caso em server, o site seja a raíz
$DIR = 'agenda';

$debug = true;

//define( 'DS', DIRECTORY_SEPARATOR );if (!defined('DS'))				define("DS", DIRECTORY_SEPARATOR);
//define( 'BASE_DIR', DIRECTORY_SEPARATOR );if (!defined('BASE_DIR'))	define("BASE_DIR", dirname( __FILE__ ) . DS);

#----------------------------------------------#
# FUNÇÕES
#----------------------------------------------#

/* DEBUG */
if ($debug !== false) {
	error_reporting(E_ALL);
} else {
	error_reporting(0);
}