<?php
//mysql_connect — Abre uma conexão com um servidor MySQL

$con = @mysqli_connect('localhost', 'root', '', 'agenda');
if (!$con) {
    echo "Error: " . mysqli_connect_error();
    exit();
}
mysqli_query($con, "SET NAMES 'utf8'");
mysqli_query($con, 'SET character_set_connection=utf8');
mysqli_query($con, 'SET character_set_client=utf8');
mysqli_query($con, 'SET character_set_results=utf8');