<?php

// Incluir o arquivo com a conexão com banco de dados
include_once './conexao.php';

// QUERY para recuperar os usuários
$query_colors = "SELECT color_id, nome_tipo FROM color  ";
//$query_colors = "SELECT id, name FROM colors WHERE id = 100 ORDER BY name ASC";

// Prepara a QUERY
$result_colors = $conn->prepare($query_colors);

// Executar a QUERY
$result_colors->execute();

// Acessar o IF quando encontrar usuário no banco de dados
if(($result_colors) and ($result_colors->rowCount() != 0)){

    // Ler os registros recuperado do banco de dados
    $dados = $result_colors->fetchAll(PDO::FETCH_ASSOC);

    // Criar o array com o status e os dados
    $retorna = ['status' => true, 'ascores' => $dados];

}else{

    // Criar o array com o status e os dados
    $retorna = ['status' => false, 'msg' => "Nenhuma categoria encontrada"];
}

// Converter o array em objeto e retornar para o JavaScript
echo json_encode($retorna);