<?php
include_once 'core/config.php';
include_once 'core/conexao.php';

if ((empty($_POST['num'])) || (empty($_POST['nome'])) || (empty($_POST['email']))) {
     echo 0;
} else {
     $userid = (int) filter_var($_POST['userid'], FILTER_SANITIZE_STRING);
     $num = filter_var($_POST['num'], FILTER_SANITIZE_STRING);
     $nome = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);
     $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
     if ((!empty($_POST['password'])) or (!empty($_POST['password_confirma']))) {
          $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);
          $password_confirma = filter_var($_POST['password_confirma'], FILTER_SANITIZE_STRING);
     }
     $a = $b = $c = $d = 1;
     $total = 0;

     // NÚMERO MECANOGRAFICO
     if ($stmt = $con->prepare("SELECT user_id, nome_login, email FROM login WHERE user_id=? or nome_login=? or email=?")) {
          $stmt->bind_param('sss', $num, $nome, $email);
          $stmt->execute();
          $result = $stmt->get_result();
          $numrow = $result->num_rows;
          $row = mysqli_fetch_row($result);
          if ($numrow >= 1) {
               $user_id_ins = $row[0];
               $nome_login_ins = $row[1];
               $email_ins = $row[2];
               // num mecanográfico
               if ($user_id_ins != $num) {
                    if ($stmt = $con->prepare("SELECT user_id FROM login WHERE user_id=?")) {
                         $stmt->bind_param('s', $num);
                         $stmt->execute();
                         $result = $stmt->get_result();
                         $stmt->close();
                         $row = $result->num_rows;
                         if ($row <= 0) {
                              $a = 2;
                         } elseif ($row >= 1) {
                              echo 1;
                              die();
                         }
                    }
               }

               // NOME
               if ($nome_login_ins != $nome) {
                    if ($stmt = $con->prepare("SELECT user_id, nome_login FROM login WHERE user_id<>? and nome_login=?")) {
                         $stmt->bind_param('is', $num, $nome);
                         $stmt->execute();
                         $result = $stmt->get_result();
                         $stmt->close();
                         $row = $result->num_rows;
                         if ($row <= 0) {
                              $b = 2;
                         } elseif ($row >= 1) {
                              echo 2;
                              die();
                         }
                    }
               }

               // EMAIL
               if ($email != $email_ins) {

                    if (strpos($email, 'cm-espinho.pt')) {
                         if ($stmt = $con->prepare("SELECT user_id, email FROM login WHERE user_id<>? and email=?")) {
                              $stmt->bind_param('is', $num, $email);
                              $stmt->execute();
                              $result = $stmt->get_result();
                              $stmt->close();
                              $row = $result->num_rows;
                              if ($row <= 0) {
                                   $c = 2;
                              } elseif ($row >= 1) {
                                   echo 4;
                                   die();
                              }
                         }
                    } else {
                         echo 5;
                         die();
                    }
               } // else echo "o mail é igual e é $email";
          }
     }
     // VERIFICAR A PASSWORD
     if ((!empty($_POST['password'])) or (!empty($_POST['password_confirma']))) {
          if ($password != $password_confirma) {
               echo 8;
               die();
          } else {
               if (strlen(trim($password)) < 8) {
                    echo 6;
               } else {
                    //Verificar as senhas contem numero e letra ERRADO AINDA
                    if (!preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password)) {
                         echo 7;
                         die();
                    }
                    $d = 1;
               }
               $password_nova = md5($password);
          }
     }
     // FAZER O UPDATE
     $total = $a + $b + $c;
     // echo $total;
     // echo "   -  $d";
     if ($total == "1" or $d != "0") {
          if ((!empty($_POST['password'])) or (!empty($_POST['password_confirma']))) {
               $sql1 = "UPDATE login SET user_id='$num', nome_login='$nome', email='$email',  hash_session='1', password='$password_nova' WHERE user_id=$userid";
          } else {
               $sql1 = "UPDATE login SET user_id='$num', nome_login='$nome', email='$email' WHERE user_id=$userid";
          }
          if (mysqli_query($con, $sql1)) {
               echo 9;
               die();
           }
     }
}