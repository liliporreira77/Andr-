<?php
include_once 'core/conexao.php';

$a = $b = $c =  $final = 0;

if ((empty($_POST['mecanografico'])) or (empty($_POST['nome'])) or (empty($_POST['email']))) {
  echo 5;
} else {
  //VERIFICA NÚMERO MECANOGRÁFICO
  if (isset($_POST['mecanografico'])) {
    $num_mec = filter_var($_POST['mecanografico'], FILTER_SANITIZE_STRING);

    if ($stmt = $con->prepare("SELECT user_id FROM login WHERE user_id=?")) {
      $stmt->bind_param('s', $num_mec);
      $stmt->execute();
      $result = $stmt->get_result();
      $stmt->close();

      $row = $result->num_rows;

      if ($row == 0) {
        
        $a = 1;
      } elseif ($row >= 1) {
        echo 1;
        die();
     }
    } else {
      echo 'erro de conexão!';
    }
  }

  //VERIFICA NOME
  if (isset($_POST['nome'])) {
    $nome = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);

    if ($stmt = $con->prepare("SELECT nome_login FROM login WHERE nome_login=?")) {
      $stmt->bind_param('s', $nome);
      $stmt->execute();
      $result = $stmt->get_result();
      $stmt->close();
      $row = $result->num_rows;

      if ($row == 0) {
        
        $b = 1;
      } elseif ($row >= 1) {
        echo 2;
      }
    } else {
      echo 'erro de conexão!';
    }
  }

  //VERIFICA EMAIL
  if (isset($_POST['email'])) {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
    if (strpos($email, 'cm-espinho.pt')) {
      if ($stmt = $con->prepare("SELECT email FROM login WHERE email=?")) {
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        $row = $result->num_rows;

        if ($row == 0) {
          $c = 1;
          
        } elseif ($row >= 1) {
          echo 3;
        }
      } else {
        echo 'erro de conexão!';
      }
    } else {
      echo 6;
    }
  }
  $final = $a + $b + $c;

  if ($final == 3) {


    // POST DADOS
    $num_mec = filter_var($_POST['mecanografico'], FILTER_SANITIZE_STRING);
    $nome = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);

    // CRIAR PASSWORD AUTOMÁTICA
    $senha_hash_md5 = md5($num_mec);
    $hash_session = 0;
    // INSERIR NA BASE DE DADOS 
    $sql = "INSERT INTO login (user_id, nome_login, email, password, hash_session) VALUES ('$num_mec', '$nome', '$email', '$senha_hash_md5', '$hash_session')";
    if ($con->query($sql) === true) {
        echo 4;
    } else {
        echo "Error: " . $sql . "<br>" . $con->error;
    }

  }
}
