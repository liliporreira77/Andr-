<?php

// Incluir o arquivo com a conexão com banco de dados
include_once './conexao.php';

// Receber os dados enviado pelo JavaScript
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

// Recuperar os dados do usuário no banco de dados
$query_user = "SELECT user_id, nome_login, email FROM login where user_id=:user_id LIMIT 1";

// Prepara a QUERY
$result_user = $conn->prepare($query_user);

// Substituir o link pelo valor
$result_user->bindParam(':user_id', $dados['ins_user_id']);

// Executar a QUERY
$result_user->execute();


// Recuperar os dados das cores
$query_colors = "SELECT color_id, nome_tipo, color FROM color WHERE color_id=:color_id LIMIT 1";

// Prepara a QUERY
$result_colors = $conn->prepare($query_colors);


// Substituir o link pelo valor
$result_colors->bindParam(':color_id', $dados['ins_color_id']);

// Executar a QUERY
$result_colors->execute();

$row_colors = $result_colors->fetch(PDO::FETCH_ASSOC);

//Inserir anexos
$countfiles = count($_FILES['files']['name']);
    // Upload directory
    $upload_location = "uploads/" . $dados['ins_user_id']. "/";
    if (!file_exists($upload_location)) {
        mkdir("uploads/" . $dados['ins_user_id']); //aqui ele irá criar a pasta
        $upload_location = "$upload_location/";
    } else  $upload_location = $upload_location;
    // To store uploaded files path
    $files_arr = array();
    // Loop all files
    for ($index = 0; $index < $countfiles; $index++) {
        if (isset($_FILES['files']['name'][$index]) && $_FILES['files']['name'][$index] != '') {
            // File name
            $filename = $_FILES['files']['name'][$index];
            // Get extension
            $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            // Valid image extension
            $valid_ext = array("png", "jpeg", "jpg");
            // Check extension
            if (in_array($ext, $valid_ext)) {
                // File path
                $path = $upload_location . $filename;
                // Upload file
                if (move_uploaded_file($_FILES['files']['tmp_name'][$index], $path)) {
                    $files_arr[] = $path;
                    $a = 1;
                }
            }
        }
    }
    // echo json_encode($files_arr);

// Ler os dados do usuário
$row_user = $result_user->fetch(PDO::FETCH_ASSOC);

// Criar a QUERY cadastrar evento no banco de dados
$query_ins_event = "INSERT INTO events (title, obs, color_id, start, end, user_id, url) VALUES (:title, :obs, :color_id, :start, :end, :user_id, :url)";

// Prepara a QUERY
$ins_event = $conn->prepare($query_ins_event);

// // Substituir o link pelo valor
$ins_event->bindParam(':title', $dados['ins_title']);
$ins_event->bindParam(':obs', $dados['ins_obs']);
$ins_event->bindParam(':start', $dados['ins_start']);
$ins_event->bindParam(':end', $dados['ins_end']);
$ins_event->bindParam(':color_id', $dados['ins_color_id']);
$ins_event->bindParam(':user_id', $dados['ins_user_id']);
$ins_event->bindParam(':url',$path);

// // Verificar se consegui cadastrar corretamente
if ($ins_event->execute()) {
    $retorna = ['status' => true, 
    'msg' => 'Evento foi inserido com sucesso!', 
    'id' => $conn->lastInsertId(), 
    'title' => $dados['ins_title'], 
    'obs' => $dados['ins_obs'], 
    'start' => $dados['ins_start'], 
    'end' => $dados['ins_end'],
    'url' => $path, 
    'nome_tipo' => $row_colors['nome_tipo'], 
    'color' => $row_colors['color'], 
    'user_id' => $row_user['user_id'],
    'nome_login' => $row_user['nome_login']];
} else {
    $retorna = ['status' => false, 'msg' => 'Erro: Evento não foi inserido!'];
}


// Converter o array em objeto e retornar para o JavaScript
echo json_encode($retorna);
