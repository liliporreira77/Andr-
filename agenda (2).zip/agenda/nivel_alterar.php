<div class="container content__boxed" style="text-align: center;">
    <div id="divCenter">
        <div class="form-block">
            <form method="post" action="" id="novoregisto">
                <?php
                $nivel_id = isset($_GET['nivel_id']) ? $_GET['nivel_id'] : '';
                if ($nivel_id != '') {
                    $nmec = $nivel_id; ?>
                    <h1>Editar Tipo de Utilizador<br> </h1>
                    <h1> </h1>
                <?php }
                $result = mysqli_query($con, "SELECT * FROM nivel WHERE nivel_id = $nmec LIMIT 1");
                $row = mysqli_fetch_row($result);
                $nivel_id = $row[0]; //echo $nivel_id
                $nome_nivel = $row[1];
                $descricao = $row[2];
                ?>
                <div id="msg_num_mec"></div>
                <div id="formfields">
                    <input type="hidden" id="nivel_id" name="nivel_id" value="<?php echo $nivel_id ?>">
                    <label for="nome_nivel" id="labels">Nome do Nível: </label>
                    <div class="wrapper"><input type="text" name="nome_nivel" id="nome_nivel" value="<?php echo $nome_nivel ?>"><br></div>
                    <label for="descricao" id="labels">Descrição:</label>
                    <div class="wrapper"><input type="text" name="descricao" id="descricao" value="<?php echo $descricao ?>"><br></div>

                    <div class="labelbotton"> <input id="submit_new_user" type="button" value="Gravar" class="button-default form-submit">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        var nivel_id = '<?php echo  $nivel_id; ?>';

        //validação
        $('#submit_new_user').click(function() {
            var onivel_id = $('#nivel_id').val();
            var onome_nivel = $('#nome_nivel').val();
            var adescricao = $('#descricao').val();
            $.ajax({
                url: "nivel_alterar_actions.php",
                type: "POST",
                data: {
                    nivel_id: onivel_id,
                    nome_nivel: onome_nivel,
                    descricao: adescricao,
                }
            }).done(function(data) {
                //	console.log(data);
                //alert(data);
                //TUDO OK
                if (data == 0) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O Tipo de Utilizador foi atualizado com sucesso!</div>'
                    );
                    setTimeout(function() {
                        history.back();
                    }, 3000);
                    //$('#Terminar Registo').prop('disabled', true);
                }

                //Validar Preenchimento obrigatório
                if (data == 1) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Todos os campos são de preenchimento obrigatório. Por favor, complete o formulário!</div>'
                    );

                    //$('#Terminar Registo').prop('disabled', true);
                }

                //Validar nome_nivel
                else if (data == 3) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já existe outro Tipo de Utilizador com o mesmo nome! Tente outro nome ou mantanha o mesmo.</div>'
                    );

                    //$('#Terminar Registo').prop('disabled', true);
                }

            }).fail(function(jqXHR, textStatus) {
                console.log("Request failed: " + textStatus);
            });
        });




    });
</script>