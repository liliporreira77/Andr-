<?php 
include_once './conexao.php';
verifica_session();

?><span id="msg"></span>
<div class="card border-light shadow">
            <div class="card-body">
                <div id='calendar'></div>
            </div>
        </div>
<!-- Button trigger modal -->

<?php  

$sql = "SELECT * FROM color ORDER BY nome_tipo";

$result = $conn->query($sql);

/* fetch associative array */

?>
<!-- Modal visualizar-->
<div class="modal fade" id="visualizarModal" tabindex="-1" aria-labelledby="visualizarModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="visualizarModalLabel">Detalhes do Evento</h1>

                <h1 class="modal-title fs-5" id="editarModalLabel" style="display: none;">Editar o Evento</h1>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <span id="msgViewEvento"></span>

                <div id="visualizarEvento">
                    <dl class="row">
                        <dt class="col-sm-6">Número do evento</dt>
                        <dd class="col-sm-9" id="visualizar_id"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-4">Título</dt>
                        <dd class="col-sm-9" id="visualizar_titulo"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-4">Ínício</dt>
                        <dd class="col-sm-9" id="visualizar_inicio"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-4">Fim</dt>
                        <dd class="col-sm-9" id="visualizar_fim"></dd>
                    </dl>

                    <dl class="row"  type="hidden">
                        <dt class="col-sm-4">Id evento: </dt>
                        <dd class="col-sm-9" id="visualizar_color_id"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-6">Tipologia: </dt>
                        <dd class="col-sm-9" id="visualizar_nome_tipo"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-6">Num. Mecanográfico: </dt>
                        <dd class="col-sm-9" id="visualizar_user_id"></dd>

                    </dl>
                    <dl class="row">
                        <dt class="col-sm-4">Nome do login: </dt>
                        <dd class="col-sm-9" id="visualizar_nome_login"></dd>

                    </dl>

                    <dl class="row">
                        <dt class="col-sm-3">Observação: </dt>
                        <dd class="col-sm-11" id="visualizar_obs"></dd>
                        </dl>
                        <dl class="row">
                            <dt class="col-sm-3">Anexos: </dt>
                            <dd class="col-sm-11" id="visualizar_img" target="_blank" ></dd>
                         <!-- <dt class="col-sm-11" ><a href="uploads/1048/ÓRGÃOS SOCIAIS DA APEE.jpg" target="_blank" style="width: 16%;"><img src="uploads/1048/ÓRGÃOS SOCIAIS DA APEE.jpg" class="img-thumbnail" alt="/uploads/1048/ÓRGÃOS SOCIAIS DA APEE.jpg"></a></dt> -->
                    </dl>

                    <button class="btn btn-warning" id="btnViewEditEvento">Editar</button>
                    <?php if($_SESSION["user_id"]==1219){?>
                                <button type="button" class="btn btn-danger" id="btnApagarEvento">Apagar</button>
                           <?php
                           } else {?> <br>
                           <dl class="row"> <dd class="col-sm-11" style="padding-left:0 !important;padding-top: 1em !important;" ><?php
                            echo "Para eliminar um evento torna-se necessário enviar um email para o administrador do programa, liliana.ribeiro@cm-espinho.pt, com a indicação do evento, data e uma breve justificação pelo o qual o mesmo será eliminado.";}
                             ?></dd></dl>
                </div>

                <div id="editarEvento" style="display: none;">

                    <span id="msgEditEvento"></span>

                    <form method="POST" id="formEditEvento">

                        <input type="hidden" name="edit_id" id="edit_id">

                        <div class="row mb-3">
                            <label for="edit_title" class="col-sm-3 col-form-label">Título</label>
                            <div class="col-sm-9">
                                <input type="text" name="edit_title" class="form-control" id="edit_title"
                                    placeholder="Título do evento">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="edit_start" class="col-sm-3 col-form-label">Início</label>
                            <div class="col-sm-9">
                                <input type="datetime-local" name="edit_start" class="form-control" id="edit_start">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="edit_end" class="col-sm-3 col-form-label">Fim</label>
                            <div class="col-sm-9">
                                <input type="datetime-local" name="edit_end" class="form-control" id="edit_end">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="edit_color_id" class="col-sm-3 col-form-label">Tipologia</label>
                            <div class="col-sm-9">
                                <select name="edit_color_id" class="form-control" id="edit_color_id">
                                    <option value="">Selecione</option>
                                </select>
                            </div>
                        </div> 
                        <div class="row mb-3">
                            <label for="edit_user_id" class="col-sm-3 col-form-label">Utilizador</label>
                            <div class="col-sm-9">
                                <select name="edit_user_id" class="form-control" id="edit_user_id">
                                    <option value="">Selecione</option>
                                </select>
                            </div>
                        </div> 
                        <div class="row mb-3">
                            <label for="edit_obs" class="col-sm-3 col-form-label">Observação</label>
                            <div class="col-sm-9">
                                <input type="text" name="edit_obs" class="form-control" id="edit_obs"
                                    placeholder="Observação do evento">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="formFileMultiple" class="form-label">Multiple files input example</label>
                            <input class="form-control" type="file" id="formFileMultiple" multiple>
                        </div>

                        <button type="button" name="btnViewEvento" class="btn btn-primary"
                            id="btnViewEvento">Cancelar</button>

                        <button type="submit" name="btnEditEvento" class="btn btn-warning"
                            id="btnEditEvento">Guardar</button>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

</div>

<!-- Modal inserir-->
<div class="modal fade" id="inserirModal" tabindex="-1" aria-labelledby="inserirModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-6" id="inserirModalLabel">Inserir novo evento</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <span id="msginsEvento"></span>
                <form method="post" id="insertEvent">
                    <div class="row mb-3">
                        <label for="ins_title" class="col-sm-3 col-form-label">Título</label>
                        <div class="col-sm-9">
                            <input type="name" name="ins_title" class="form-control" id="ins_title"
                                placeholder="Título do evento">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="ins_start" class="col-sm-3 col-form-label">Data inícial</label>
                        <div class="col-sm-9">
                            <input type="datetime-local" name="ins_start" class="form-control" id="ins_start">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="ins_end" class="col-sm-3 col-form-label">Data final</label>
                        <div class="col-sm-9">
                            <input type="datetime-local" name="ins_end" class="form-control" id="ins_end">
                        </div>
                    </div>


                    <div class="row mb-3">

                        <label for="ins_color_id" class="col-sm-3 col-form-label">Tipologia</label>
                        <div class="col-sm-9">
                            <select name="ins_color_id" id="ins_color_id">
                                <option value="">Escolha</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">

                        <label for="ins_user_id" class="col-sm-3 col-form-label">Utilizador</label>
                        <div class="col-sm-9">
                            <select name="ins_user_id" id="ins_user_id">
                                <option value="">Escolha</option>

                            </select>
                        </div>
                    </div>
    
                    <div class="row mb-3">
                        <label for="ins_obs" class="col-sm-3 col-form-label">Observações</label>
                        <div class="col-sm-9">
                            <input type="name"  name="ins_obs" class="form-control" id="ins_obs"
                                placeholder="Observações do evento">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="ins_imagem" class="form-label">Insira um ficheiro</label>
                        <input type="file" id='files' name="files[]" id="labels" multiple style="border:0"><br>
                    </div>
    
                    <button type="submit" name="btnInsEvento" class="btn btn-success" id="btnInsEvento">Inserir</button>

                </form>
            </div>
        </div>
    </div>
    