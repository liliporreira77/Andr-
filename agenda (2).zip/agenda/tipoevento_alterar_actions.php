<?php
include_once('core/conexao.php');
// verifica_session();

if (empty($_POST['nome_tipo']))
    echo 1;
else {
    //VERIFICA nome_tipo
    $color_id = (int) filter_var($_POST['color_id'], FILTER_SANITIZE_STRING);
    $nome_tipo = filter_var($_POST['nome_tipo'], FILTER_SANITIZE_STRING);
    $color = filter_var($_POST['color'], FILTER_SANITIZE_STRING);
    $stmt = $con->prepare("SELECT color_id, nome_tipo, color FROM color WHERE color_id<>? and nome_tipo=?");
    $stmt->bind_param('ss', $color_id, $nome_tipo);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrow = $result->num_rows;
    if ($numrow >= 1) {
        $row = mysqli_fetch_array($result);
        $color_id_i = $row['color_id'];
        $nome_tipo_i = $row['nome_tipo'];
        if ($nome_tipo == $nome_tipo_i) {
            echo 3;
            die();
        }
    }
    // UPDATE NA BASE DE DADOS
    $sql = "UPDATE color SET nome_tipo='$nome_tipo', color='$color' WHERE color_id=$color_id";
    // echo $sql;
    if (mysqli_query($con, $sql)) {
        echo 0;
        die();
    }
}
