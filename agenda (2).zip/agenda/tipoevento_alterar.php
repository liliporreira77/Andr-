<?php
// verifica_session();
?>
<div class="container content__boxed" style="text-align: center;">
    <div id="divCenter">
        <div class="form-block">
            <form method="post" action="" id="novoregisto">
                <?php
                $color_id = isset($_GET['color_id']) ? $_GET['color_id'] : '';
                if ($color_id != '') {
                    $nmec = $color_id; ?>
                    <h1>Editar tipo de evento<br> </h1>
                    <h1> </h1>
                <?php }
                $result = mysqli_query($con, "SELECT color_id, nome_tipo, color FROM color WHERE color_id = $color_id  LIMIT 1");
                $row = mysqli_fetch_row($result);
                $color_id = $row[0]; //echo $color_id
                $nome_tipo = $row[1];
                $color = $row[2]; 
                ?>
                <div id="msg_num_mec"></div>
                <div id="formfields">
                    <input type="hidden" id="color_id" name="color_id" value="<?php echo $color_id ?>">
                    <label for="nome_tipo" id="labels">Nome do tipo de evento: </label>
                    <div class="wrapper"><input type="text" name="nome_tipo" id="nome_tipo" value="<?php echo $nome_tipo ?>"><br></div>
                                       
                    <label for="descricao" class="form-itens">Selecione a cor do evento: </label>
                     <div class="form-itens">
                         <input type="color" name="color" id="color"value="<?php echo $color ?>">
                     </div>
                    <div class="labelbotton"> <input id="submit_new_user" type="button" value="Gravar" class="button-default form-submit">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        var color_id = '<?php echo  $color_id; ?>';

        //validação
        $('#submit_new_user').click(function() {
            var ocolor_id = $('#color_id').val();
            var onome_tipo = $('#nome_tipo').val();
            var ocolor = $('#color').val();
            $.ajax({
                url: "tipoevento_alterar_actions.php",
                type: "POST",
                data: {
                    color_id: ocolor_id,
                    nome_tipo: onome_tipo,
                    color: ocolor,
                }
            }).done(function(data) {
                if (data == 0) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O tipo de evento foi atualizado com sucesso!</div>'
                    );
                    setTimeout(function() {
                        history.back();
                    }, 3000);
                }
                //Validar Preenchimento obrigatório
                if (data == 1) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Todos os campos são de preenchimento obrigatório. Por favor, complete o formulário!</div>'
                    );
                }

                //Validar nome_tipo
                else if (data == 3) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já existe outro tipo de evento  com o mesmo nome! Tente outro nome.</div>'
                    );

                    //$('#Terminar Registo').prop('disabled', true);
                }

            }).fail(function(jqXHR, textStatus) {
                console.log("Request failed: " + textStatus);
            });
        });




    });
</script>